package com.example.myapplication;


import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

public class Text_content_Activity extends AppCompatActivity {
    private TextView text_content;
    private ImageView iContent;
    private int category = 0;
    private int position = 0;
    private int [] array_cube = {R.string.cube_1, R.string.cube_2};
    private int [] array_konus = {R.string.konus_1, R.string.konus_2};
    private int [] array_sfera = {R.string.sfera_1, R.string.sfera_2};

    private int [] array_image_cube = {R.drawable.cub, R.drawable.cub};
    private int [] array_image_sfera = {R.drawable.sfera, R.drawable.sfera};
    private int [] array_image_konus = {R.drawable.konus, R.drawable.konus};
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.text_content);
        text_content = findViewById(R.id.text_main_content);
        iContent = findViewById(R.id.imageContent);
        reciveIntent();
    }
    private void reciveIntent(){
        Intent i = getIntent();
        if(i != null)
        {
category = i.getIntExtra("category", 0);
position = i.getIntExtra("position", 0);
        }
        switch (category)
        {
            case 0:
                iContent.setImageResource(array_image_cube[position]);
                text_content.setText(array_cube[position]);
                break;
            case 1:
                iContent.setImageResource(array_image_sfera[position]);
                text_content.setText(array_sfera[position]);
                break;
            case 2:
                iContent.setImageResource(array_image_konus[position]);
                text_content.setText(array_konus[position]);
                break;
           }
    }
}
